from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import joblib
import pandas as pd
import json
import logging

# Configure logging to log into a file
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler()  # Optionally keep logging to console as well
    ]
)

# Define the feature columns and the model files
feature_columns = ['interest_rate', 'age', 'loan_amount', 'number_of_defaults', 'salary',
                   'outstanding_balance', 'location', 'marital_status', 'gender', 'is_employed']

# Load the models dynamically
logging.info("Loading models...")
model_files = ["RandomForest_model.joblib", "LogisticRegression_model.joblib", "SVC_model.joblib",
               "DecisionTree_model.joblib", "NaiveBayes_model.joblib"]
models = {model_file.split('_')[0]: joblib.load(model_file) for model_file in model_files}
logging.info("Models loaded successfully.")

# Load label mappings from labelMapping.json
logging.info("Loading label mappings...")
with open('label_encoders.json', 'r') as f:
    label_mapping = json.load(f)
logging.info("Label mappings loaded successfully.")

# Load target mappings from targetsMappings.json
logging.info("Loading target mappings...")
with open('TargetMappings.json', 'r') as f:
    target_mapping = json.load(f)
logging.info("Target mappings loaded successfully.")

# Inverse the target mapping for easier lookup
inv_target_mapping = {v: k for k, v in target_mapping.items()}

# Mapping from camel case to original feature names
feature_mapping = {
    'interestRate': 'interest_rate',
    'loanAmount': 'loan_amount',
    'numberOfDefaults': 'number_of_defaults',
    'outstandingBalance': 'outstanding_balance',
    'maritalStatus': 'marital_status',
    'isEmployed': 'is_employed'
}

# Initialize FastAPI
app = FastAPI()

# Define the request body structure
class PredictionRequest(BaseModel):
    interestRate: float
    age: int
    loanAmount: float
    numberOfDefaults: int
    salary: float
    outstandingBalance: float
    location: str
    maritalStatus: str
    gender: str
    isEmployed: bool

# Root route
@app.get("/")
def home():
    return {"message": "Owner: Obey Njanjeni"}

# Endpoint to get predictions
@app.post("/predict")
def predict(data: PredictionRequest):
    logging.info("Received prediction request.")
    logging.info(f"Request data: {data}")

    # Convert request data to DataFrame
    input_data = pd.DataFrame([data.dict()])
    logging.info(f"Converted input data to DataFrame: {input_data}")

    # Rename columns using the feature mapping
    input_data.rename(columns=feature_mapping, inplace=True)
    logging.info(f"Renamed columns using feature mapping: {input_data}")

    # Strip leading/trailing whitespace from input data to match label encodings
    input_data = input_data.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # Convert boolean to string representation for encoding
    input_data['is_employed'] = input_data['is_employed'].astype(str)

    # Handle categorical columns using label mappings
    for column, mapping in label_mapping.items():
        if column in input_data.columns:
            input_data[column] = input_data[column].map(mapping).fillna(-1).astype(int)
            logging.info(f"Encoded column '{column}': {input_data[column]}")

    # Ensure all feature columns are present
    missing_cols = [col for col in feature_columns if col not in input_data.columns]
    for col in missing_cols:
        input_data[col] = 0  # or any other default value or handling
    logging.info(f"Added missing columns: {input_data}")

    # Ensure columns are in the correct order as expected by the model
    input_data = input_data[feature_columns]

    # Include the raw payload in the response
    raw_payload = data.dict()

    predictions = {}
    for model_name, model in models.items():
        try:
            prediction = model.predict(input_data)[0]
            probabilities = model.predict_proba(input_data)[:, 1][0] if hasattr(model, "predict_proba") else None
            predictions[model_name] = {
                "predicted_class": inv_target_mapping[str(prediction)],
                "predicted_probability": float(probabilities) if probabilities is not None else None
            }
            logging.info(f"Prediction from {model_name}: {prediction}, Probability: {probabilities}")
        except Exception as e:
            logging.error(f"Error in {model_name} model: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error in {model_name} model: {str(e)}")

    logging.info(f"Final predictions: {predictions}")

    # Return both predictions and raw payload in the response
    return {
        "Payload": raw_payload,
        "Predictions": predictions
    }

# Endpoint to get the list of models
@app.get("/models")
def get_models():
    return list(models.keys())

# Start the application with Uvicorn
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8007, reload=True)
